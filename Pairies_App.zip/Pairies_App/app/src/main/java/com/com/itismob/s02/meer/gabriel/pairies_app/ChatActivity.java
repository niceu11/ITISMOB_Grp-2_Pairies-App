package com.com.itismob.s02.meer.gabriel.pairies_app;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.ActivityChatBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.ItemChatBubbleReceivedBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.ItemChatBubbleSentBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.ChatMessage;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.MatchItem;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.UserProfile;
import com.com.itismob.s02.meer.gabriel.pairies_app.repository.PairiesRepository;

import java.util.List;

public class ChatActivity extends AppCompatActivity {

    private ActivityChatBinding binding;
    private UserProfile matchedUser;
    private String matchId;
    private ChatAdapter chatAdapter;
    private List<ChatMessage> messageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        matchedUser = (UserProfile) getIntent().getSerializableExtra("matched_user");
        matchId = getIntent().getStringExtra("match_id");

        if (matchedUser == null) {
            List<MatchItem> convs = PairiesRepository.getInstance().getConversations();
            if (!convs.isEmpty()) {
                matchedUser = convs.get(0).getUserProfile();
                matchId = convs.get(0).getMatchId();
            }
        }

        binding.btnBack.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        if (matchedUser != null) {
            binding.tvChatName.setText(matchedUser.getName());
            binding.tvChatStatus.setText(matchedUser.getActivityStatus());
            binding.ivChatVerified.setVisibility(matchedUser.isVerified() ? View.VISIBLE : View.GONE);

            if (matchedUser.getImageResId() != 0) {
                binding.ivChatAvatar.setImageResource(matchedUser.getImageResId());
            }
        }

        binding.btnSafetyMenu.setOnClickListener(v -> showSafetyMenu());

        binding.btnSend.setOnClickListener(v -> sendMessage());

        loadMessages();
    }

    private void loadMessages() {
        if (matchId == null) return;

        messageList = PairiesRepository.getInstance().getMessages(matchId);
        chatAdapter = new ChatAdapter(messageList);
        binding.rvMessages.setAdapter(chatAdapter);
        if (!messageList.isEmpty()) {
            binding.rvMessages.scrollToPosition(messageList.size() - 1);
        }
    }

    private void sendMessage() {
        String text = binding.etMessage.getText() != null ? binding.etMessage.getText().toString().trim() : "";
        if (text.isEmpty()) return;

        PairiesRepository.getInstance().sendMessage(matchId, text);
        binding.etMessage.setText("");

        messageList = PairiesRepository.getInstance().getMessages(matchId);
        chatAdapter.updateMessages(messageList);
        binding.rvMessages.scrollToPosition(messageList.size() - 1);

        // Auto-reply simulation
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!isFinishing() && matchedUser != null) {
                PairiesRepository.getInstance().sendMessage(matchId, "That sounds amazing! Can't wait ✨");
                messageList = PairiesRepository.getInstance().getMessages(matchId);
                chatAdapter.updateMessages(messageList);
                binding.rvMessages.scrollToPosition(messageList.size() - 1);
            }
        }, 1500);
    }

    private void showSafetyMenu() {
        PopupMenu menu = new PopupMenu(this, binding.btnSafetyMenu);
        menu.getMenu().add("Block User");
        menu.getMenu().add("Report User");
        menu.setOnMenuItemClickListener(item -> {
            if (item.getTitle().equals("Block User")) {
                new AlertDialog.Builder(this)
                        .setTitle("Block User")
                        .setMessage("Are you sure you want to block " + matchedUser.getName() + "? You won't see each other again.")
                        .setPositiveButton("Block", (d, w) -> {
                            PairiesRepository.getInstance().blockUser(matchedUser.getId());
                            Toast.makeText(this, matchedUser.getName() + " blocked.", Toast.LENGTH_SHORT).show();
                            finish();
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
                return true;
            } else if (item.getTitle().equals("Report User")) {
                Toast.makeText(this, "Report submitted. Thank you for helping keep Pairies safe!", Toast.LENGTH_LONG).show();
                return true;
            }
            return false;
        });
        menu.show();
    }

    private class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int TYPE_SENT = 1;
        private static final int TYPE_RECEIVED = 2;

        private List<ChatMessage> list;

        ChatAdapter(List<ChatMessage> list) { this.list = list; }

        void updateMessages(List<ChatMessage> newList) {
            this.list = newList;
            notifyDataSetChanged();
        }

        @Override
        public int getItemViewType(int position) {
            return list.get(position).isFromCurrentUser() ? TYPE_SENT : TYPE_RECEIVED;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            if (viewType == TYPE_SENT) {
                ItemChatBubbleSentBinding b = ItemChatBubbleSentBinding.inflate(getLayoutInflater(), parent, false);
                return new SentViewHolder(b);
            } else {
                ItemChatBubbleReceivedBinding b = ItemChatBubbleReceivedBinding.inflate(getLayoutInflater(), parent, false);
                return new ReceivedViewHolder(b);
            }
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            ChatMessage msg = list.get(position);
            if (holder instanceof SentViewHolder) {
                ((SentViewHolder) holder).binding.tvSentText.setText(msg.getText());
                ((SentViewHolder) holder).binding.tvSentTime.setText(msg.getTimestampFormatted());
            } else if (holder instanceof ReceivedViewHolder) {
                ((ReceivedViewHolder) holder).binding.tvReceivedText.setText(msg.getText());
                ((ReceivedViewHolder) holder).binding.tvReceivedTime.setText(msg.getTimestampFormatted());
            }
        }

        @Override
        public int getItemCount() { return list.size(); }

        class SentViewHolder extends RecyclerView.ViewHolder {
            ItemChatBubbleSentBinding binding;
            SentViewHolder(ItemChatBubbleSentBinding b) { super(b.getRoot()); this.binding = b; }
        }

        class ReceivedViewHolder extends RecyclerView.ViewHolder {
            ItemChatBubbleReceivedBinding binding;
            ReceivedViewHolder(ItemChatBubbleReceivedBinding b) { super(b.getRoot()); this.binding = b; }
        }
    }
}