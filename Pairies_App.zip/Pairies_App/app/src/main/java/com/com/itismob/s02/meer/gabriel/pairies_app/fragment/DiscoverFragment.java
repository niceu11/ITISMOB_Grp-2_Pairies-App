package com.com.itismob.s02.meer.gabriel.pairies_app.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.com.itismob.s02.meer.gabriel.pairies_app.R;
import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.FragmentDiscoverBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.ItemSwipeCardBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.dialog.FilterBottomSheetDialog;
import com.com.itismob.s02.meer.gabriel.pairies_app.dialog.MatchDialog;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.UserProfile;
import com.com.itismob.s02.meer.gabriel.pairies_app.repository.PairiesRepository;
import com.google.android.material.chip.Chip;

import java.util.List;

public class DiscoverFragment extends Fragment {

    private FragmentDiscoverBinding binding;
    private ItemSwipeCardBinding currentCardBinding;
    private ItemSwipeCardBinding nextCardBinding;
    private List<UserProfile> currentQueue;
    private int currentIndex = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentDiscoverBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.btnFilter.setOnClickListener(v -> {
            FilterBottomSheetDialog dialog = new FilterBottomSheetDialog();
            dialog.setOnApplyCallback(this::reloadQueue);
            dialog.show(getParentFragmentManager(), "filter_dialog");
        });

        binding.btnLike.setOnClickListener(v -> {
            animateButtonClick(v);
            if (currentCardBinding != null) {
                currentCardBinding.tvLikeStamp.animate().alpha(1.0f).setDuration(100).start();
                currentCardBinding.getRoot().animate().x(1200f).rotation(30f).setDuration(220).withEndAction(this::performLike).start();
            } else {
                performLike();
            }
        });

        binding.btnPass.setOnClickListener(v -> {
            animateButtonClick(v);
            if (currentCardBinding != null) {
                currentCardBinding.tvPassStamp.animate().alpha(1.0f).setDuration(100).start();
                currentCardBinding.getRoot().animate().x(-1200f).rotation(-30f).setDuration(220).withEndAction(this::performPass).start();
            } else {
                performPass();
            }
        });

        binding.btnSuperLike.setOnClickListener(v -> {
            animateButtonClick(v);
            if (currentCardBinding != null) {
                currentCardBinding.tvSuperStamp.animate().alpha(1.0f).setDuration(100).start();
                currentCardBinding.getRoot().animate().y(-1400f).scaleX(0.8f).scaleY(0.8f).setDuration(250).withEndAction(() -> {
                    performLike();
                }).start();
            } else {
                performLike();
            }
        });

        binding.btnUndo.setOnClickListener(v -> {
            animateButtonClick(v);
            UserProfile undone = PairiesRepository.getInstance().undoLastSwipe();
            if (undone != null) {
                reloadQueue();
                playRewindAnimation();
            }
        });

        binding.btnResetStack.setOnClickListener(v -> reloadQueue());

        reloadQueue();
    }

    private void animateButtonClick(View v) {
        v.setScaleX(0.85f);
        v.setScaleY(0.85f);
        v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(180).start();
    }

    private void playRewindAnimation() {
        if (currentCardBinding != null) {
            View card = currentCardBinding.getRoot();
            card.setTranslationX(-1200f);
            card.setRotation(-180f);
            card.setScaleX(0.6f);
            card.setScaleY(0.6f);
            card.animate()
                    .translationX(0f)
                    .rotation(0f)
                    .scaleX(1.0f)
                    .scaleY(1.0f)
                    .setDuration(350)
                    .start();
        }
    }

    private void reloadQueue() {
        currentQueue = PairiesRepository.getInstance().getDiscoverQueue();
        currentIndex = 0;
        showCurrentCard();
    }

    private void showCurrentCard() {
        binding.cardStackContainer.removeAllViews();

        if (currentQueue == null || currentIndex >= currentQueue.size()) {
            binding.cardStackContainer.setVisibility(View.GONE);
            binding.actionsBar.setVisibility(View.GONE);
            binding.llEmptyState.setVisibility(View.VISIBLE);
            return;
        }

        binding.cardStackContainer.setVisibility(View.VISIBLE);
        binding.actionsBar.setVisibility(View.VISIBLE);
        binding.llEmptyState.setVisibility(View.GONE);

        // Bind Next Card (3D Depth Stack Effect Behind Top Card)
        if (currentIndex + 1 < currentQueue.size()) {
            UserProfile nextProfile = currentQueue.get(currentIndex + 1);
            nextCardBinding = ItemSwipeCardBinding.inflate(getLayoutInflater(), binding.cardStackContainer, false);
            bindCardData(nextCardBinding, nextProfile);
            View nextView = nextCardBinding.getRoot();
            nextView.setScaleX(0.92f);
            nextView.setScaleY(0.92f);
            nextView.setTranslationY(20f);
            binding.cardStackContainer.addView(nextView);
        }

        // Bind Top Card
        UserProfile profile = currentQueue.get(currentIndex);
        currentCardBinding = ItemSwipeCardBinding.inflate(getLayoutInflater(), binding.cardStackContainer, false);
        bindCardData(currentCardBinding, profile);
        binding.cardStackContainer.addView(currentCardBinding.getRoot());

        setupDragGesture(currentCardBinding.getRoot(), profile);
    }

    private void bindCardData(ItemSwipeCardBinding cardBinding, UserProfile profile) {
        cardBinding.tvNameAge.setText(profile.getName() + ", " + profile.getAge());
        cardBinding.tvDistance.setText(profile.getDistanceKm() + " km away • " + profile.getLocationName());
        cardBinding.tvActiveStatus.setText(profile.getActivityStatus());
        cardBinding.tvBio.setText(profile.getBio());
        cardBinding.tvRelationshipGoal.setText("✨ " + profile.getRelationshipGoal());
        cardBinding.ivVerified.setVisibility(profile.isVerified() ? View.VISIBLE : View.GONE);

        if (profile.getSpotifySong() != null && !profile.getSpotifySong().isEmpty()) {
            cardBinding.cardSpotify.setVisibility(View.VISIBLE);
            cardBinding.tvSpotifyTrack.setText(profile.getSpotifySong() + " - " + profile.getSpotifyArtist());
        } else {
            cardBinding.cardSpotify.setVisibility(View.GONE);
        }

        if (profile.getImageResId() != 0) {
            cardBinding.ivProfilePhoto.setImageResource(profile.getImageResId());
        }

        cardBinding.chipGroupInterests.removeAllViews();
        for (String interest : profile.getInterests()) {
            Chip chip = new Chip(requireContext());
            chip.setText(interest);
            chip.setChipBackgroundColorResource(R.color.pairies_chip_bg);
            chip.setTextColor(getResources().getColor(R.color.pairies_charcoal, null));
            cardBinding.chipGroupInterests.addView(chip);
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupDragGesture(View cardView, UserProfile profile) {
        cardView.setOnTouchListener(new View.OnTouchListener() {
            private float dX, dY, initialX, initialY;
            private boolean isDragging = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dX = v.getX() - event.getRawX();
                        dY = v.getY() - event.getRawY();
                        initialX = v.getX();
                        initialY = v.getY();
                        isDragging = true;
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        if (!isDragging) return false;
                        float newX = event.getRawX() + dX;
                        float newY = event.getRawY() + dY;
                        v.setX(newX);
                        v.setY(newY);

                        float diffX = newX - initialX;
                        float diffY = newY - initialY;
                        float rotation = diffX / 22f;
                        v.setRotation(rotation);

                        // Dynamic Stamp Feedback Badges
                        if (currentCardBinding != null) {
                            if (diffX > 30) {
                                float alpha = Math.min(1.0f, diffX / 220f);
                                currentCardBinding.tvLikeStamp.setAlpha(alpha);
                                currentCardBinding.tvPassStamp.setAlpha(0.0f);
                                currentCardBinding.tvSuperStamp.setAlpha(0.0f);
                            } else if (diffX < -30) {
                                float alpha = Math.min(1.0f, -diffX / 220f);
                                currentCardBinding.tvPassStamp.setAlpha(alpha);
                                currentCardBinding.tvLikeStamp.setAlpha(0.0f);
                                currentCardBinding.tvSuperStamp.setAlpha(0.0f);
                            } else if (diffY < -100) {
                                float alpha = Math.min(1.0f, -diffY / 200f);
                                currentCardBinding.tvSuperStamp.setAlpha(alpha);
                                currentCardBinding.tvLikeStamp.setAlpha(0.0f);
                                currentCardBinding.tvPassStamp.setAlpha(0.0f);
                            } else {
                                currentCardBinding.tvLikeStamp.setAlpha(0.0f);
                                currentCardBinding.tvPassStamp.setAlpha(0.0f);
                                currentCardBinding.tvSuperStamp.setAlpha(0.0f);
                            }
                        }

                        // Scale background card in 3D stack
                        if (nextCardBinding != null) {
                            float dragRatio = Math.min(1.0f, Math.abs(diffX) / 400f);
                            float nextScale = 0.92f + (0.08f * dragRatio);
                            nextCardBinding.getRoot().setScaleX(nextScale);
                            nextCardBinding.getRoot().setScaleY(nextScale);
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        isDragging = false;
                        float finalDiffX = v.getX() - initialX;
                        float finalDiffY = v.getY() - initialY;

                        if (finalDiffX > 220) {
                            // Swipe Right -> Like
                            v.animate().x(1200f).rotation(35f).setDuration(200).withEndAction(() -> performLike()).start();
                        } else if (finalDiffX < -220) {
                            // Swipe Left -> Pass
                            v.animate().x(-1200f).rotation(-35f).setDuration(200).withEndAction(() -> performPass()).start();
                        } else if (finalDiffY < -200) {
                            // Swipe Up -> Super Like
                            v.animate().y(-1400f).scaleX(0.8f).scaleY(0.8f).setDuration(200).withEndAction(() -> performLike()).start();
                        } else {
                            // Reset position & hide stamps
                            v.animate().x(initialX).y(initialY).rotation(0f).setDuration(200).start();
                            if (currentCardBinding != null) {
                                currentCardBinding.tvLikeStamp.animate().alpha(0.0f).setDuration(150).start();
                                currentCardBinding.tvPassStamp.animate().alpha(0.0f).setDuration(150).start();
                                currentCardBinding.tvSuperStamp.animate().alpha(0.0f).setDuration(150).start();
                            }
                            if (nextCardBinding != null) {
                                nextCardBinding.getRoot().animate().scaleX(0.92f).scaleY(0.92f).setDuration(200).start();
                            }
                        }
                        return true;
                }
                return false;
            }
        });
    }

    private void performLike() {
        if (currentQueue != null && currentIndex < currentQueue.size()) {
            UserProfile profile = currentQueue.get(currentIndex);
            boolean matched = PairiesRepository.getInstance().swipeRight(profile);

            if (matched) {
                MatchDialog dialog = MatchDialog.newInstance(profile);
                dialog.show(getParentFragmentManager(), "match_dialog");
            }

            currentIndex++;
            showCurrentCard();
        }
    }

    private void performPass() {
        if (currentQueue != null && currentIndex < currentQueue.size()) {
            UserProfile profile = currentQueue.get(currentIndex);
            PairiesRepository.getInstance().swipeLeft(profile);

            currentIndex++;
            showCurrentCard();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        currentCardBinding = null;
        nextCardBinding = null;
    }
}