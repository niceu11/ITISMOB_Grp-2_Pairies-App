package com.com.itismob.s02.meer.gabriel.pairies_app.model;

import java.io.Serializable;

public class MatchItem implements Serializable {
    private String matchId;
    private UserProfile userProfile;
    private long matchedTimestamp;
    private int hoursRemaining; // Bumble 24h expiration timer
    private String lastMessage;
    private String lastMessageTime;
    private boolean hasUnread;

    public MatchItem() {}

    public MatchItem(String matchId, UserProfile userProfile, long matchedTimestamp, int hoursRemaining,
                     String lastMessage, String lastMessageTime, boolean hasUnread) {
        this.matchId = matchId;
        this.userProfile = userProfile;
        this.matchedTimestamp = matchedTimestamp;
        this.hoursRemaining = hoursRemaining;
        this.lastMessage = lastMessage;
        this.lastMessageTime = lastMessageTime;
        this.hasUnread = hasUnread;
    }

    public String getMatchId() { return matchId; }
    public void setMatchId(String matchId) { this.matchId = matchId; }

    public UserProfile getUserProfile() { return userProfile; }
    public void setUserProfile(UserProfile userProfile) { this.userProfile = userProfile; }

    public long getMatchedTimestamp() { return matchedTimestamp; }
    public void setMatchedTimestamp(long matchedTimestamp) { this.matchedTimestamp = matchedTimestamp; }

    public int getHoursRemaining() { return hoursRemaining; }
    public void setHoursRemaining(int hoursRemaining) { this.hoursRemaining = hoursRemaining; }

    public String getLastMessage() { return lastMessage; }
    public void setLastMessage(String lastMessage) { this.lastMessage = lastMessage; }

    public String getLastMessageTime() { return lastMessageTime; }
    public void setLastMessageTime(String lastMessageTime) { this.lastMessageTime = lastMessageTime; }

    public boolean isHasUnread() { return hasUnread; }
    public void setHasUnread(boolean hasUnread) { this.hasUnread = hasUnread; }
}