package com.com.itismob.s02.meer.gabriel.pairies_app.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.com.itismob.s02.meer.gabriel.pairies_app.ChatActivity;
import com.com.itismob.s02.meer.gabriel.pairies_app.R;
import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.FragmentMatchesBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.ItemConversationBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.ItemMatchQueueBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.MatchItem;
import com.com.itismob.s02.meer.gabriel.pairies_app.repository.PairiesRepository;

import java.util.List;

public class MatchesFragment extends Fragment {

    private FragmentMatchesBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentMatchesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadData();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        if (binding == null) return;

        List<MatchItem> queue = PairiesRepository.getInstance().getMatchQueue();
        List<MatchItem> convs = PairiesRepository.getInstance().getConversations();

        binding.rvMatchQueue.setAdapter(new QueueAdapter(queue));
        binding.rvConversations.setAdapter(new ConvAdapter(convs));
    }

    // Match Queue Adapter
    private class QueueAdapter extends RecyclerView.Adapter<QueueAdapter.ViewHolder> {
        private final List<MatchItem> items;

        QueueAdapter(List<MatchItem> items) { this.items = items; }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ItemMatchQueueBinding b = ItemMatchQueueBinding.inflate(getLayoutInflater(), parent, false);
            return new ViewHolder(b);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            MatchItem item = items.get(position);
            holder.binding.tvQueueName.setText(item.getUserProfile().getName());
            holder.binding.tvTimerBadge.setText(item.getHoursRemaining() + "h");

            if (item.getUserProfile().getImageResId() != 0) {
                holder.binding.ivQueueAvatar.setImageResource(item.getUserProfile().getImageResId());
            }

            holder.itemView.setOnClickListener(v -> openChat(item));
        }

        @Override
        public int getItemCount() { return items.size(); }

        class ViewHolder extends RecyclerView.ViewHolder {
            ItemMatchQueueBinding binding;
            ViewHolder(ItemMatchQueueBinding b) { super(b.getRoot()); this.binding = b; }
        }
    }

    // Conversations Adapter
    private class ConvAdapter extends RecyclerView.Adapter<ConvAdapter.ViewHolder> {
        private final List<MatchItem> items;

        ConvAdapter(List<MatchItem> items) { this.items = items; }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ItemConversationBinding b = ItemConversationBinding.inflate(getLayoutInflater(), parent, false);
            return new ViewHolder(b);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            MatchItem item = items.get(position);
            holder.binding.tvConvName.setText(item.getUserProfile().getName());
            holder.binding.tvLastMessage.setText(item.getLastMessage());
            holder.binding.tvConvTime.setText(item.getLastMessageTime());
            holder.binding.ivConvVerified.setVisibility(item.getUserProfile().isVerified() ? View.VISIBLE : View.GONE);
            holder.binding.vUnreadBadge.setVisibility(item.isHasUnread() ? View.VISIBLE : View.GONE);

            if (item.getUserProfile().getImageResId() != 0) {
                holder.binding.ivConvAvatar.setImageResource(item.getUserProfile().getImageResId());
            }

            holder.itemView.setOnClickListener(v -> openChat(item));
        }

        @Override
        public int getItemCount() { return items.size(); }

        class ViewHolder extends RecyclerView.ViewHolder {
            ItemConversationBinding binding;
            ViewHolder(ItemConversationBinding b) { super(b.getRoot()); this.binding = b; }
        }
    }

    private void openChat(MatchItem matchItem) {
        Intent intent = new Intent(requireContext(), ChatActivity.class);
        intent.putExtra("matched_user", matchItem.getUserProfile());
        intent.putExtra("match_id", matchItem.getMatchId());
        startActivity(intent);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}