package com.com.itismob.s02.meer.gabriel.pairies_app;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.ActivityMainBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.fragment.DiscoverFragment;
import com.com.itismob.s02.meer.gabriel.pairies_app.fragment.MatchesFragment;
import com.com.itismob.s02.meer.gabriel.pairies_app.fragment.ProfileFragment;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(0, systemBars.top, 0, 0);
            binding.bottomNavigation.setPadding(0, 0, 0, systemBars.bottom);
            return insets;
        });

        binding.viewPager.setAdapter(new MainPagerAdapter(this));
        binding.viewPager.setUserInputEnabled(false); // Tab navigation via bottom bar

        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_discover) {
                binding.viewPager.setCurrentItem(0, false);
                return true;
            } else if (itemId == R.id.nav_matches) {
                binding.viewPager.setCurrentItem(1, false);
                return true;
            } else if (itemId == R.id.nav_profile) {
                binding.viewPager.setCurrentItem(2, false);
                return true;
            }
            return false;
        });
    }

    private static class MainPagerAdapter extends FragmentStateAdapter {
        MainPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
            super(fragmentActivity);
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            switch (position) {
                case 0:
                    return new DiscoverFragment();
                case 1:
                    return new MatchesFragment();
                case 2:
                    return new ProfileFragment();
                default:
                    return new DiscoverFragment();
            }
        }

        @Override
        public int getItemCount() {
            return 3;
        }
    }
}