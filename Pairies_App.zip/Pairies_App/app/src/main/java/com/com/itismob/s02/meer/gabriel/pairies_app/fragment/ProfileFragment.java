package com.com.itismob.s02.meer.gabriel.pairies_app.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.com.itismob.s02.meer.gabriel.pairies_app.EditProfileActivity;
import com.com.itismob.s02.meer.gabriel.pairies_app.LoginActivity;
import com.com.itismob.s02.meer.gabriel.pairies_app.PhotoVerificationActivity;
import com.com.itismob.s02.meer.gabriel.pairies_app.R;
import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.FragmentProfileBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.UserProfile;
import com.com.itismob.s02.meer.gabriel.pairies_app.repository.PairiesRepository;
import com.google.android.material.chip.Chip;

public class ProfileFragment extends Fragment {

    private FragmentProfileBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadProfileData();

        binding.btnEditProfile.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), EditProfileActivity.class);
            startActivity(intent);
        });

        binding.btnPhotoVerify.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), PhotoVerificationActivity.class);
            startActivity(intent);
        });

        binding.btnLogout.setOnClickListener(v -> {
            Toast.makeText(requireContext(), "Logged out", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(requireContext(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadProfileData();
    }

    private void loadProfileData() {
        if (binding == null) return;

        UserProfile me = PairiesRepository.getInstance().getCurrentUser();
        if (me != null) {
            binding.tvMyNameAge.setText(me.getName() + ", " + me.getAge());
            binding.tvMyBio.setText(me.getBio());
            binding.tvMySpotifyTrack.setText(me.getSpotifySong() + " - " + me.getSpotifyArtist());
            binding.ivVerifiedBadge.setVisibility(me.isVerified() ? View.VISIBLE : View.GONE);
            binding.tvMyStatus.setText(me.isVerified() ? "Verified Profile • Active now" : "Unverified • Active now");

            if (me.getImageResId() != 0) {
                binding.ivMyProfilePhoto.setImageResource(me.getImageResId());
            }

            binding.chipGroupMyInterests.removeAllViews();
            for (String interest : me.getInterests()) {
                Chip chip = new Chip(requireContext());
                chip.setText(interest);
                chip.setChipBackgroundColorResource(R.color.pairies_chip_bg);
                chip.setTextColor(getResources().getColor(R.color.pairies_charcoal, null));
                binding.chipGroupMyInterests.addView(chip);
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}