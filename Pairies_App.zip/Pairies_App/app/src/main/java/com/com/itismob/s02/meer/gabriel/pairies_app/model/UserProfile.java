package com.com.itismob.s02.meer.gabriel.pairies_app.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class UserProfile implements Serializable {
    private String id;
    private String name;
    private int age;
    private String bio;
    private String gender;
    private int distanceKm;
    private String locationName; // New York location name (e.g. "SoHo, New York")
    private int imageResId; // Resource ID for high-res profile photo
    private List<String> profilePhotos;
    private List<String> interests;
    private String relationshipGoal;
    private String spotifySong;
    private String spotifyArtist;
    private boolean isVerified;
    private String activityStatus;

    public UserProfile() {
        this.profilePhotos = new ArrayList<>();
        this.interests = new ArrayList<>();
    }

    public UserProfile(String id, String name, int age, String bio, String gender, int distanceKm,
                       String locationName, int imageResId, List<String> profilePhotos,
                       List<String> interests, String relationshipGoal, String spotifySong,
                       String spotifyArtist, boolean isVerified, String activityStatus) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.bio = bio;
        this.gender = gender;
        this.distanceKm = distanceKm;
        this.locationName = locationName;
        this.imageResId = imageResId;
        this.profilePhotos = profilePhotos != null ? profilePhotos : new ArrayList<>();
        this.interests = interests != null ? interests : new ArrayList<>();
        this.relationshipGoal = relationshipGoal;
        this.spotifySong = spotifySong;
        this.spotifyArtist = spotifyArtist;
        this.isVerified = isVerified;
        this.activityStatus = activityStatus;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public int getDistanceKm() { return distanceKm; }
    public void setDistanceKm(int distanceKm) { this.distanceKm = distanceKm; }

    public String getLocationName() { return locationName; }
    public void setLocationName(String locationName) { this.locationName = locationName; }

    public int getImageResId() { return imageResId; }
    public void setImageResId(int imageResId) { this.imageResId = imageResId; }

    public List<String> getProfilePhotos() { return profilePhotos; }
    public void setProfilePhotos(List<String> profilePhotos) { this.profilePhotos = profilePhotos; }

    public List<String> getInterests() { return interests; }
    public void setInterests(List<String> interests) { this.interests = interests; }

    public String getRelationshipGoal() { return relationshipGoal; }
    public void setRelationshipGoal(String relationshipGoal) { this.relationshipGoal = relationshipGoal; }

    public String getSpotifySong() { return spotifySong; }
    public void setSpotifySong(String spotifySong) { this.spotifySong = spotifySong; }

    public String getSpotifyArtist() { return spotifyArtist; }
    public void setSpotifyArtist(String spotifyArtist) { this.spotifyArtist = spotifyArtist; }

    public boolean isVerified() { return isVerified; }
    public void setVerified(boolean verified) { isVerified = verified; }

    public String getActivityStatus() { return activityStatus; }
    public void setActivityStatus(String activityStatus) { this.activityStatus = activityStatus; }
}