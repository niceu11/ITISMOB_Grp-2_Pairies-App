package com.com.itismob.s02.meer.gabriel.pairies_app.dialog;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.bumptech.glide.Glide;
import com.com.itismob.s02.meer.gabriel.pairies_app.ChatActivity;
import com.com.itismob.s02.meer.gabriel.pairies_app.R;
import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.DialogMatchBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.UserProfile;
import com.com.itismob.s02.meer.gabriel.pairies_app.repository.PairiesRepository;

public class MatchDialog extends DialogFragment {

    private static final String ARG_MATCHED_USER = "matched_user";
    private DialogMatchBinding binding;
    private UserProfile matchedUser;

    public static MatchDialog newInstance(UserProfile matchedUser) {
        MatchDialog fragment = new MatchDialog();
        Bundle args = new Bundle();
        args.putSerializable(ARG_MATCHED_USER, matchedUser);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, R.style.Theme_Pairies_App);
        if (getArguments() != null) {
            matchedUser = (UserProfile) getArguments().getSerializable(ARG_MATCHED_USER);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DialogMatchBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (matchedUser != null) {
            binding.tvMatchSub.setText("You and " + matchedUser.getName() + " liked each other. Don't keep them waiting!");

            if (matchedUser.getImageResId() != 0) {
                binding.ivMatchAvatar.setImageResource(matchedUser.getImageResId());
            }
        }

        UserProfile myProfile = PairiesRepository.getInstance().getCurrentUser();
        if (myProfile != null && myProfile.getImageResId() != 0) {
            binding.ivMyAvatar.setImageResource(myProfile.getImageResId());
        }

        binding.btnSendMessage.setOnClickListener(v -> {
            dismiss();
            if (matchedUser != null) {
                Intent intent = new Intent(requireContext(), ChatActivity.class);
                intent.putExtra("matched_user", matchedUser);
                startActivity(intent);
            }
        });

        binding.btnKeepSwiping.setOnClickListener(v -> dismiss());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}