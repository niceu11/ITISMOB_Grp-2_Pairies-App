package com.com.itismob.s02.meer.gabriel.pairies_app;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.ActivityEditProfileBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.UserProfile;
import com.com.itismob.s02.meer.gabriel.pairies_app.repository.PairiesRepository;

public class EditProfileActivity extends AppCompatActivity {

    private ActivityEditProfileBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityEditProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(0, systemBars.top, 0, systemBars.bottom);
            return insets;
        });

        binding.btnBack.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        UserProfile me = PairiesRepository.getInstance().getCurrentUser();
        if (me != null) {
            binding.etEditName.setText(me.getName());
            binding.etEditAge.setText(String.valueOf(me.getAge()));
            binding.etEditBio.setText(me.getBio());
            binding.etEditSpotifySong.setText(me.getSpotifySong());
            binding.etEditSpotifyArtist.setText(me.getSpotifyArtist());
            binding.etEditGoal.setText(me.getRelationshipGoal());
        }

        binding.btnSaveProfile.setOnClickListener(v -> saveProfile());
    }

    private void saveProfile() {
        UserProfile me = PairiesRepository.getInstance().getCurrentUser();
        if (me != null) {
            String name = binding.etEditName.getText() != null ? binding.etEditName.getText().toString().trim() : me.getName();
            String ageStr = binding.etEditAge.getText() != null ? binding.etEditAge.getText().toString().trim() : String.valueOf(me.getAge());
            String bio = binding.etEditBio.getText() != null ? binding.etEditBio.getText().toString().trim() : me.getBio();
            String song = binding.etEditSpotifySong.getText() != null ? binding.etEditSpotifySong.getText().toString().trim() : me.getSpotifySong();
            String artist = binding.etEditSpotifyArtist.getText() != null ? binding.etEditSpotifyArtist.getText().toString().trim() : me.getSpotifyArtist();
            String goal = binding.etEditGoal.getText() != null ? binding.etEditGoal.getText().toString().trim() : me.getRelationshipGoal();

            me.setName(name);
            try {
                me.setAge(Integer.parseInt(ageStr));
            } catch (NumberFormatException ignored) {}
            me.setBio(bio);
            me.setSpotifySong(song);
            me.setSpotifyArtist(artist);
            me.setRelationshipGoal(goal);

            PairiesRepository.getInstance().updateCurrentUser(me);
            Toast.makeText(this, "Profile updated successfully!", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}