package com.com.itismob.s02.meer.gabriel.pairies_app.repository;

import com.com.itismob.s02.meer.gabriel.pairies_app.R;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.ChatMessage;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.MatchItem;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.UserProfile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PairiesRepository {
    private static PairiesRepository instance;

    private UserProfile currentUser;
    private final List<UserProfile> discoverQueue;
    private final List<UserProfile> swipedHistory;
    private final List<MatchItem> matchesList;
    private final Map<String, List<ChatMessage>> chatMessagesMap;
    private final Set<String> blockedUserIds;

    // Discovery filters
    private int minAge = 18;
    private int maxAge = 35;
    private int maxDistanceKm = 50;
    private String genderPreference = "Everyone";

    private PairiesRepository() {
        discoverQueue = new ArrayList<>();
        swipedHistory = new ArrayList<>();
        matchesList = new ArrayList<>();
        chatMessagesMap = new HashMap<>();
        blockedUserIds = new HashSet<>();

        initMockData();
    }

    public static synchronized PairiesRepository getInstance() {
        if (instance == null) {
            instance = new PairiesRepository();
        }
        return instance;
    }

    private void initMockData() {
        // Current User Profile (New York based)
        currentUser = new UserProfile(
                "user_me",
                "Riley Morgan",
                21,
                "DLSU Exchange Student in NYC | Coffee addict ☕ | Love indie pop music & late night Central Park walks ✨",
                "Male",
                0,
                "Upper East Side, New York",
                R.drawable.img_profile_gabriel,
                Arrays.asList("android.resource://com.com.itismob.s02.meer.gabriel.pairies_app/" + R.drawable.img_profile_gabriel),
                Arrays.asList("Coffee", "Indie Music", "Photography", "Central Park", "NYC Diners"),
                "Looking for a serious relationship",
                "Cruel Summer",
                "Taylor Swift",
                true,
                "Active now"
        );

        // 20 Diverse New York Profiles for Swiping Feed
        UserProfile p1 = new UserProfile("p1", "Aria Vance", 22, "Design enthusiast & matcha latte lover. Looking for someone to explore cozy SoHo cafes with! 🍵✨", "Female", 3, "SoHo, New York", R.drawable.img_profile_sophia, null, Arrays.asList("Matcha", "UI Design", "Art Galleries", "SoHo"), "Long-term relationship", "As It Was", "Harry Styles", true, "Active 10m ago");
        UserProfile p2 = new UserProfile("p2", "Maya Lin", 21, "Fairy aesthetic lover 🧚‍♀️ | DLSU CS major | Let's talk about Broadway shows & Brooklyn concerts!", "Female", 5, "Brooklyn, New York", R.drawable.img_profile_alexa, null, Arrays.asList("Concerts", "Broadway", "Reading", "DUMBO"), "Open to dating", "Golden Hour", "JVKE", true, "Active now");
        UserProfile p3 = new UserProfile("p3", "Elena Rostova", 20, "Sunset chaser & foodie 🍣 | Greenwich Village explorer looking for good vibes & deep conversations.", "Female", 8, "Greenwich Village, New York", R.drawable.img_profile_christine, null, Arrays.asList("Sushi", "Sunsets", "Dogs", "Greenwich"), "Something casual", "Espresso", "Sabrina Carpenter", false, "Online 1h ago");
        UserProfile p4 = new UserProfile("p4", "Sienna Miller", 22, "Architecture student 🏛️ | Always down for acoustic jam sessions & rooftop dinners overflowing with jazz.", "Female", 12, "Upper West Side, New York", R.drawable.img_profile_georgina, null, Arrays.asList("Architecture", "Acoustic", "Rooftops", "Wine"), "Long-term relationship", "Vampire", "Olivia Rodrigo", true, "Active now");
        UserProfile p5 = new UserProfile("p5", "Camila Torres", 21, "Fashion & digital media photographer 📸 | Seeking a partner in crime for DUMBO weekend getaways!", "Female", 15, "DUMBO, New York", R.drawable.img_profile_paris, null, Arrays.asList("Fashion", "Photography", "Beach", "Movies"), "Dating & see where it goes", "Feather", "Sabrina Carpenter", true, "Active 3h ago");
        UserProfile p6 = new UserProfile("p6", "Nora Kensington", 23, "Vintage vinyl collector & espresso martini lover in Meatpacking 🍸", "Female", 4, "Meatpacking, New York", R.drawable.img_profile_nora, null, Arrays.asList("Vinyl Records", "Cocktails", "Art History"), "Serious relationship", "Dance the Night", "Dua Lipa", true, "Active now");
        UserProfile p7 = new UserProfile("p7", "Harper Reed", 20, "Tribeca film student 🎬 | Looking for a popcorn buddy for indie film marathons.", "Female", 6, "Tribeca, New York", R.drawable.img_profile_harper, null, Arrays.asList("Indie Films", "Cinema", "Popcorn"), "Open to dating", "Anti-Hero", "Taylor Swift", false, "Active 20m ago");
        UserProfile p8 = new UserProfile("p8", "Stella Dupont", 22, "French pastry chef in East Village 🥐 | I'll bake you croissants if you bring good music!", "Female", 7, "East Village, New York", R.drawable.img_profile_stella, null, Arrays.asList("Baking", "French Culture", "Pastries"), "Long-term relationship", "Levitating", "Dua Lipa", true, "Active now");
        UserProfile p9 = new UserProfile("p9", "Lily Zhang", 21, "Marine biology student at NYU 🛶 | Loves sunset kayaking around Hudson River Park.", "Female", 9, "Battery Park, New York", R.drawable.img_profile_lily, null, Arrays.asList("Kayaking", "NYU", "Ocean Science"), "Dating", "Ocean Eyes", "Billie Eilish", true, "Active 2h ago");
        UserProfile p10 = new UserProfile("p10", "Chloe Bennett", 22, "Film camera enthusiast in Williamsburg 📷 | Coffee shop reviewer & dog lover.", "Female", 10, "Williamsburg, New York", R.drawable.img_profile_chloe, null, Arrays.asList("Film Photography", "Coffee", "Dogs"), "Open to dating", "Lover", "Taylor Swift", true, "Active 30m ago");
        UserProfile p11 = new UserProfile("p11", "Victoria Sterling", 23, "Fashion designer on Upper East Side ✨ | Runway shows & rooftop gala gal.", "Female", 2, "Upper East Side, New York", R.drawable.img_profile_6, null, Arrays.asList("Fashion", "Gala", "Design"), "Serious relationship", "Style", "Taylor Swift", true, "Active now");
        UserProfile p12 = new UserProfile("p12", "Gaby Hayes", 21, "Flatiron tech intern 💻 | Love bouldering, board games, and boba tea runs.", "Female", 5, "Flatiron, New York", R.drawable.img_profile_7, null, Arrays.asList("Tech", "Bouldering", "Boba"), "Dating", "Bad Habit", "Steve Lacy", false, "Active 4h ago");
        UserProfile p13 = new UserProfile("p13", "Brooke Hudson", 22, "Gramercy Park yoga instructor 🧘‍♀️ | Plant mom & smoothie bowl fanatic.", "Female", 6, "Gramercy Park, New York", R.drawable.img_profile_8, null, Arrays.asList("Yoga", "Plants", "Smoothies"), "Long-term relationship", "Flowers", "Miley Cyrus", true, "Active now");
        UserProfile p14 = new UserProfile("p14", "Penelope Scott", 20, "NoHo art student 🎨 | Museum dates & vintage thrifting adventures.", "Female", 4, "NoHo, New York", R.drawable.img_profile_9, null, Arrays.asList("Museums", "Art", "Thrift"), "Something casual", "Solar Power", "Lorde", false, "Active 1h ago");
        UserProfile p15 = new UserProfile("p15", "Hazel Murphy", 23, "Lower East Side speakeasy host 🎷 | Jazz enthusiast & late night taco run buddy.", "Female", 8, "Lower East Side, New York", R.drawable.img_profile_10, null, Arrays.asList("Jazz", "Tacos", "Speakeasies"), "Open to dating", "Calm Down", "Rema", true, "Active 15m ago");
        UserProfile p16 = new UserProfile("p16", "Aurora Blake", 21, "Midtown theater performer 🎭 | Musical lover looking for a duet partner.", "Female", 11, "Midtown, New York", R.drawable.img_profile_sophia, null, Arrays.asList("Theater", "Broadway", "Singing"), "Long-term relationship", "Greedy", "Tate McRae", true, "Active now");
        UserProfile p17 = new UserProfile("p17", "Ivy Thorne", 22, "Chelsea gallery manager 🖼️ | Modern art lover & matcha espresso fusion fan.", "Female", 3, "Chelsea, New York", R.drawable.img_profile_alexa, null, Arrays.asList("Art", "Matcha", "Galleries"), "Serious relationship", "Kill Bill", "SZA", true, "Active 10m ago");
        UserProfile p18 = new UserProfile("p18", "Daisy Cole", 20, "Bushwick thrift shop manager 🎸 | Indie rock lover & rooftop DJing.", "Female", 14, "Bushwick, New York", R.drawable.img_profile_christine, null, Arrays.asList("Indie Rock", "DJing", "Thrifting"), "Something casual", "Watermelon Sugar", "Harry Styles", false, "Active 2h ago");
        UserProfile p19 = new UserProfile("p19", "Ruby Delgado", 23, "Astoria food blogger 🍕 | Let's taste-test the best pizza slices in NYC!", "Female", 16, "Astoria, New York", R.drawable.img_profile_georgina, null, Arrays.asList("Pizza", "Foodie", "Blogging"), "Dating", "Paint The Town Red", "Doja Cat", true, "Active 30m ago");
        UserProfile p20 = new UserProfile("p20", "Scarlett Rivera", 21, "Harlem jazz vocalist 🎤 | Live music enthusiast & soul food connoisseur.", "Female", 18, "Harlem, New York", R.drawable.img_profile_paris, null, Arrays.asList("Jazz", "Live Music", "Soul Food"), "Long-term relationship", "Houdini", "Dua Lipa", true, "Active now");

        discoverQueue.addAll(Arrays.asList(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20));

        // Pre-existing Matches
        UserProfile m1User = new UserProfile("m1_user", "Zoe Sterling", 23, "Pilates instructor & dog mom in Chelsea 🐶", "Female", 4, "Chelsea, New York", R.drawable.img_profile_hannah, null, Arrays.asList("Fitness", "Dogs", "Chelsea Market"), "Serious relationship", "Flowers", "Miley Cyrus", true, "Active now");
        MatchItem matchQueueItem = new MatchItem("m1", m1User, System.currentTimeMillis(), 18, "", "", false);
        matchesList.add(matchQueueItem);

        UserProfile m2User = new UserProfile("m2_user", "Isabella Rossi", 22, "Film camera enthusiast in Williamsburg 📷", "Female", 6, "Williamsburg, New York", R.drawable.img_profile_chloe, null, Arrays.asList("Film", "Movies", "Williamsburg Coffee"), "Dating", "Lover", "Taylor Swift", true, "Active 30m ago");
        MatchItem activeConvItem = new MatchItem("m2", m2User, System.currentTimeMillis() - 3600000, 24, "Hey! Loved your Spotify song pick 🎶", "2:15 PM", true);
        matchesList.add(activeConvItem);

        List<ChatMessage> cList = new ArrayList<>();
        cList.add(new ChatMessage("c1", "m2", "m2_user", "Hey Riley! Loved your Spotify song pick 🎶", "2:15 PM", false));
        cList.add(new ChatMessage("c2", "m2", "user_me", "Thanks Bella! Cruel Summer is a classic. What kind of music are you into?", "2:18 PM", true));
        cList.add(new ChatMessage("c3", "m2", "m2_user", "Mostly Taylor Swift & indie pop! Are you free for coffee in Williamsburg this week?", "2:20 PM", false));
        chatMessagesMap.put("m2", cList);
    }

    public UserProfile getCurrentUser() {
        return currentUser;
    }

    public void updateCurrentUser(UserProfile updated) {
        this.currentUser = updated;
    }

    public List<UserProfile> getDiscoverQueue() {
        List<UserProfile> filtered = new ArrayList<>();
        for (UserProfile p : discoverQueue) {
            if (!blockedUserIds.contains(p.getId()) && p.getAge() >= minAge && p.getAge() <= maxAge && p.getDistanceKm() <= maxDistanceKm) {
                filtered.add(p);
            }
        }
        return filtered;
    }

    public boolean swipeRight(UserProfile profile) {
        swipedHistory.add(profile);
        discoverQueue.remove(profile);

        // Create mutual match
        MatchItem newMatch = new MatchItem(
                "match_" + profile.getId(),
                profile,
                System.currentTimeMillis(),
                24,
                "",
                "Just now",
                false
        );
        matchesList.add(0, newMatch);
        chatMessagesMap.put(newMatch.getMatchId(), new ArrayList<>());
        return true; // Triggers "It's a Match!" celebration modal!
    }

    public void swipeLeft(UserProfile profile) {
        swipedHistory.add(profile);
        discoverQueue.remove(profile);
    }

    public UserProfile undoLastSwipe() {
        if (!swipedHistory.isEmpty()) {
            UserProfile undone = swipedHistory.remove(swipedHistory.size() - 1);
            discoverQueue.add(0, undone);
            return undone;
        }
        return null;
    }

    public List<MatchItem> getMatchQueue() {
        List<MatchItem> queue = new ArrayList<>();
        for (MatchItem m : matchesList) {
            if (!blockedUserIds.contains(m.getUserProfile().getId())) {
                List<ChatMessage> msgs = chatMessagesMap.get(m.getMatchId());
                if (msgs == null || msgs.isEmpty()) {
                    queue.add(m);
                }
            }
        }
        return queue;
    }

    public List<MatchItem> getConversations() {
        List<MatchItem> convs = new ArrayList<>();
        for (MatchItem m : matchesList) {
            if (!blockedUserIds.contains(m.getUserProfile().getId())) {
                List<ChatMessage> msgs = chatMessagesMap.get(m.getMatchId());
                if (msgs != null && !msgs.isEmpty()) {
                    convs.add(m);
                }
            }
        }
        return convs;
    }

    public List<ChatMessage> getMessages(String matchId) {
        return chatMessagesMap.getOrDefault(matchId, new ArrayList<>());
    }

    public void sendMessage(String matchId, String text) {
        List<ChatMessage> list = chatMessagesMap.computeIfAbsent(matchId, k -> new ArrayList<>());
        ChatMessage msg = new ChatMessage(
                "msg_" + System.currentTimeMillis(),
                matchId,
                currentUser.getId(),
                text,
                "Just now",
                true
        );
        list.add(msg);

        // Update match last message preview
        for (MatchItem m : matchesList) {
            if (m.getMatchId().equals(matchId)) {
                m.setLastMessage(text);
                m.setLastMessageTime("Just now");
                break;
            }
        }
    }

    public void blockUser(String userId) {
        blockedUserIds.add(userId);
    }

    // Filter Getters & Setters
    public int getMinAge() { return minAge; }
    public int getMaxAge() { return maxAge; }
    public int getMaxDistanceKm() { return maxDistanceKm; }
    public String getGenderPreference() { return genderPreference; }

    public void updateFilters(int minAge, int maxAge, int maxDistanceKm, String genderPreference) {
        this.minAge = minAge;
        this.maxAge = maxAge;
        this.maxDistanceKm = maxDistanceKm;
        this.genderPreference = genderPreference;
    }
}