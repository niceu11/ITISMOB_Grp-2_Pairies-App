package com.com.itismob.s02.meer.gabriel.pairies_app;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.ActivityPhotoVerificationBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.UserProfile;
import com.com.itismob.s02.meer.gabriel.pairies_app.repository.PairiesRepository;

public class PhotoVerificationActivity extends AppCompatActivity {

    private ActivityPhotoVerificationBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityPhotoVerificationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(0, systemBars.top, 0, systemBars.bottom);
            return insets;
        });

        binding.btnBack.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        binding.btnCaptureVerify.setOnClickListener(v -> startScanning());
    }

    private void startScanning() {
        binding.btnCaptureVerify.setEnabled(false);
        binding.progressScan.setVisibility(View.VISIBLE);
        binding.tvScanInstruction.setText("Scanning face & matching pose with ML Kit...");

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!isFinishing()) {
                UserProfile me = PairiesRepository.getInstance().getCurrentUser();
                if (me != null) {
                    me.setVerified(true);
                    PairiesRepository.getInstance().updateCurrentUser(me);
                }

                Toast.makeText(this, "Photo Verification Successful! You earned a Verified Badge Blue Checkmark ✔️", Toast.LENGTH_LONG).show();
                finish();
            }
        }, 2000);
    }
}