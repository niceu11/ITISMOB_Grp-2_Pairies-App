package com.com.itismob.s02.meer.gabriel.pairies_app.dialog;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.DialogFilterBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.repository.PairiesRepository;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.List;
import java.util.Locale;

public class FilterBottomSheetDialog extends BottomSheetDialogFragment {

    private DialogFilterBinding binding;
    private Runnable onApplyCallback;

    public void setOnApplyCallback(Runnable callback) {
        this.onApplyCallback = callback;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DialogFilterBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        PairiesRepository repo = PairiesRepository.getInstance();

        binding.sliderAge.setStepSize(1.0f);
        binding.sliderDistance.setStepSize(1.0f);

        binding.sliderAge.setValues((float) repo.getMinAge(), (float) repo.getMaxAge());
        binding.tvAgeRangeVal.setText(String.format(Locale.US, "%d - %d", repo.getMinAge(), repo.getMaxAge()));

        binding.sliderDistance.setValue((float) repo.getMaxDistanceKm());
        binding.tvDistanceVal.setText(String.format(Locale.US, "%d km", repo.getMaxDistanceKm()));

        binding.sliderAge.addOnChangeListener((slider, value, fromUser) -> {
            List<Float> values = slider.getValues();
            int min = Math.round(values.get(0));
            int max = Math.round(values.get(1));
            binding.tvAgeRangeVal.setText(String.format(Locale.US, "%d - %d", min, max));
        });

        binding.sliderDistance.addOnChangeListener((slider, value, fromUser) -> {
            int dist = Math.round(value);
            binding.tvDistanceVal.setText(String.format(Locale.US, "%d km", dist));
        });

        binding.btnApplyFilters.setOnClickListener(v -> {
            List<Float> ageValues = binding.sliderAge.getValues();
            int minAge = Math.round(ageValues.get(0));
            int maxAge = Math.round(ageValues.get(1));
            int maxDist = Math.round(binding.sliderDistance.getValue());

            repo.updateFilters(minAge, maxAge, maxDist, "Everyone");

            if (onApplyCallback != null) {
                onApplyCallback.run();
            }
            dismiss();
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}