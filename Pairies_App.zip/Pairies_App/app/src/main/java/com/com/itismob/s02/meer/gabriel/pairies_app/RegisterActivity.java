package com.com.itismob.s02.meer.gabriel.pairies_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.com.itismob.s02.meer.gabriel.pairies_app.databinding.ActivityRegisterBinding;
import com.com.itismob.s02.meer.gabriel.pairies_app.model.UserProfile;
import com.com.itismob.s02.meer.gabriel.pairies_app.repository.PairiesRepository;

import java.util.Arrays;

public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(0, systemBars.top, 0, systemBars.bottom);
            return insets;
        });

        binding.btnBack.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        binding.btnSubmitRegister.setOnClickListener(v -> completeRegistration());
    }

    private void completeRegistration() {
        String name = binding.etName.getText() != null ? binding.etName.getText().toString().trim() : "";
        String bio = binding.etBio.getText() != null ? binding.etBio.getText().toString().trim() : "";
        String ageStr = binding.etAge.getText() != null ? binding.etAge.getText().toString().trim() : "20";
        int age = ageStr.isEmpty() ? 20 : Integer.parseInt(ageStr);

        if (name.isEmpty()) {
            binding.etName.setError("Name required");
            return;
        }

        UserProfile user = PairiesRepository.getInstance().getCurrentUser();
        user.setName(name);
        user.setBio(bio);
        user.setAge(age);
        PairiesRepository.getInstance().updateCurrentUser(user);

        Toast.makeText(this, "Profile created! Welcome to Pairies ✨", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}