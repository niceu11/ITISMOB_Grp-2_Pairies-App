package com.com.itismob.s02.meer.gabriel.pairies_app.model;

import java.io.Serializable;

public class ChatMessage implements Serializable {
    private String messageId;
    private String matchId;
    private String senderId;
    private String text;
    private String timestampFormatted;
    private boolean isFromCurrentUser;

    public ChatMessage() {}

    public ChatMessage(String messageId, String matchId, String senderId, String text, String timestampFormatted, boolean isFromCurrentUser) {
        this.messageId = messageId;
        this.matchId = matchId;
        this.senderId = senderId;
        this.text = text;
        this.timestampFormatted = timestampFormatted;
        this.isFromCurrentUser = isFromCurrentUser;
    }

    public String getMessageId() { return messageId; }
    public void setMessageId(String messageId) { this.messageId = messageId; }

    public String getMatchId() { return matchId; }
    public void setMatchId(String matchId) { this.matchId = matchId; }

    public String getSenderId() { return senderId; }
    public void setSenderId(String senderId) { this.senderId = senderId; }

    public String getText() { return text; }
    public void setText(String text) { this.text = text; }

    public String getTimestampFormatted() { return timestampFormatted; }
    public void setTimestampFormatted(String timestampFormatted) { this.timestampFormatted = timestampFormatted; }

    public boolean isFromCurrentUser() { return isFromCurrentUser; }
    public void setFromCurrentUser(boolean fromCurrentUser) { isFromCurrentUser = fromCurrentUser; }
}